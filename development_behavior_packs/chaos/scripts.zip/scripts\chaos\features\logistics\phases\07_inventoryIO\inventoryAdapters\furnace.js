// scripts/chaos/features/logistics/phases/07_inventoryIO/inventoryAdapters/furnace.js
export const furnaceAdapter = { type: "furnace" };

