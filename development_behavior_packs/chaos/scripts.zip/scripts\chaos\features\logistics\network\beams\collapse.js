// scripts/chaos/features/logistics/network/beams/collapse.js
import { enqueueCollapseJob } from "./jobs.js";

export { enqueueCollapseJob };
