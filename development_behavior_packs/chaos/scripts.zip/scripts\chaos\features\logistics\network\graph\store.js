// scripts/chaos/features/logistics/network/graph/store.js
import { loadLinkGraph, saveLinkGraph } from "../../persistence/storage.js";

export { loadLinkGraph, saveLinkGraph };

