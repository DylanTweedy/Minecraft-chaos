// scripts/chaos/features/logistics/phases/09_fluxConversion/flux.js
import { getFluxTier, getFluxTypeForTier, isFluxTypeId } from "../../../flux.js";
import { OrbModes } from "../../state/enums.js";
import { bumpCounter } from "../../util/insightCounters.js";

export function applyFluxConversion(ctx) {
  const cfg = ctx.cfg || {};
  const orbs = ctx.state?.orbs || [];
  const minHops = Math.max(1, Number(cfg.fluxMinHops) || 6);
  const minSpeed = Math.max(0.1, Number(cfg.fluxMinSpeed) || 0.5);
  const refineSpeed = Math.max(0.1, Number(cfg.fluxRefineSpeed) || 0.8);
  const refineHopInterval = Math.max(1, Number(cfg.fluxRefineHopInterval) || 6);

  let processed = 0;
  const max = ctx.budgets.state.flux | 0;

  for (const orb of orbs) {
    if (processed >= max) break;
    if (!orb) continue;

    if ((orb.mode === OrbModes.DRIFT || orb.mode === OrbModes.WALKING) && !isFluxTypeId(orb.itemTypeId)) {
      if (orb.hops >= minHops && (orb.speed || 0) >= minSpeed) {
        orb.itemTypeId = getFluxTypeForTier(1);
        orb.mode = OrbModes.FLUX;
        bumpCounter(ctx, "flux_converted");
      }
    } else if (isFluxTypeId(orb.itemTypeId)) {
      const tier = getFluxTier(orb.itemTypeId);
      if (tier > 0 && tier < 5 && orb.hops > 0 && (orb.hops % refineHopInterval) === 0 && (orb.speed || 0) >= refineSpeed) {
        orb.itemTypeId = getFluxTypeForTier(tier + 1);
        bumpCounter(ctx, "flux_refined");
      }
    }

    processed++;
  }
}






