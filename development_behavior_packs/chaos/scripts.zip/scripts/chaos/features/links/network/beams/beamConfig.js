// scripts/chaos/features/links/shared/beamConfig.js
// Shared constants for beam-related systems.

export const MAX_BEAM_LEN = 16;
