// scripts/chaos/features/links/beam/config.js
const BEAM_ID = "chaos:beam";

const AXIS_X = "x";
const AXIS_Y = "y";
const AXIS_Z = "z";

export {
  BEAM_ID,
  AXIS_X,
  AXIS_Y,
  AXIS_Z,
};
