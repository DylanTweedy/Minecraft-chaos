// scripts/chaos/features/logistics/phases/07_inventoryIO/inventoryAdapters/chest.js
export const chestAdapter = { type: "chest" };

