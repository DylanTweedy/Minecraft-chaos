// scripts/chaos/features/logistics/phases/07_inventoryIO/inventoryAdapters/hopperLike.js
export const hopperLikeAdapter = { type: "hopperLike" };

