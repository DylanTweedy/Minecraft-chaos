// scripts/chaos/features/logistics/persistence/dpKeys.js

export const DP_LOGISTICS_SCHEMA = "chaos:logistics_schema_v1";
export const DP_LOGISTICS_ORBS = "chaos:logistics_orbs_v1";
export const DP_LOGISTICS_PRISM_LEVELS = "chaos:logistics_prism_levels_v1";
export const DP_LOGISTICS_GRAPH = "chaos:logistics_graph_v1";
export const DP_LOGISTICS_DRIFT_CURSORS = "chaos:logistics_drift_cursors_v1";

