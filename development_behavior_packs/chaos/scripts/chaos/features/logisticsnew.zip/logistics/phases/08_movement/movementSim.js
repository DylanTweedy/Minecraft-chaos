// scripts/chaos/features/logistics/phases/08_movement/movementSim.js
import { OrbStates } from "../../state/enums.js";
import { dropOrbOnBrokenEdge } from "./beamBreakDrops.js";
import { bumpCounter } from "../../util/insightCounters.js";
import { parseKey } from "../../keys.js";
import { queueFxParticle } from "../../../../fx/fx.js";

function resolveOrbParticle(FX, itemTypeId) {
  if (!FX) return null;
  if (itemTypeId && FX.particleExoticOrbById && FX.particleExoticOrbById[itemTypeId]) {
    return FX.particleExoticOrbById[itemTypeId];
  }
  if (itemTypeId && FX.particleFluxOrbByTier && Array.isArray(FX.particleFluxOrbByTier)) {
    let fluxTier = 0;
    if (itemTypeId === "chaos:flux_1") fluxTier = 1;
    else if (itemTypeId === "chaos:flux_2") fluxTier = 2;
    else if (itemTypeId === "chaos:flux_3") fluxTier = 3;
    else if (itemTypeId === "chaos:flux_4") fluxTier = 4;
    else if (itemTypeId === "chaos:flux_5") fluxTier = 5;
    if (fluxTier > 0) return FX.particleFluxOrbByTier[fluxTier - 1] || null;
  }
  return FX.particleTransferItem || null;
}

export function advanceMovement(ctx) {
  const linkGraph = ctx.services?.linkGraph;
  const cacheManager = ctx.services?.cacheManager;
  const FX = ctx.FX;
  const maxOrbFx = Math.max(0, Number(ctx.cfg?.maxOrbFxPerTick) || 0);
  let orbFxUsed = 0;
  const orbs = ctx.state?.orbs || [];
  if (!linkGraph) return;
  let moved = 0;
  const maxMoves = ctx.budgets.state.movements | 0;

  for (const orb of orbs) {
    if (moved >= maxMoves) break;
    if (!orb || orb.state !== OrbStates.IN_FLIGHT) continue;

    const edge = linkGraph?.getEdgeBetweenKeys(orb.edgeFromKey, orb.edgeToKey);
    if (!edge) {
      dropOrbOnBrokenEdge(ctx, orb, edge, "beam_break");
      orb.state = null;
      orb._remove = true;
      moved++;
      continue;
    }

    if (!(orb.edgeEpoch | 0)) {
      orb.edgeEpoch = edge.epoch | 0;
    }

    if ((edge.epoch | 0) !== (orb.edgeEpoch | 0)) {
      dropOrbOnBrokenEdge(ctx, orb, edge, "beam_break");
      orb.state = null;
      orb._remove = true;
      moved++;
      continue;
    }

    const speed = Math.max(0.01, Number(orb.speed) || 1);
    orb.progress += speed;

    if (maxOrbFx > 0 && orbFxUsed < maxOrbFx) {
      const from = parseKey(orb.edgeFromKey);
      const to = parseKey(orb.edgeToKey);
      if (from && to && from.dimId === to.dimId) {
        const dim = cacheManager?.getDimensionCached
          ? cacheManager.getDimensionCached(from.dimId)
          : ctx.world?.getDimension?.(from.dimId);
        const particleId = resolveOrbParticle(FX, orb.itemTypeId);
        if (dim && particleId) {
          const edgeLen = Math.max(0.0001, edge.length | 0);
          const t = Math.max(0, Math.min(1, (orb.progress || 0) / edgeLen));
          const px = from.x + (to.x - from.x) * t + 0.5;
          const py = from.y + (to.y - from.y) * t + 0.5;
          const pz = from.z + (to.z - from.z) * t + 0.5;
          queueFxParticle(dim, particleId, { x: px, y: py, z: pz });
          orbFxUsed++;
        }
      }
    }

    if (orb.progress >= (edge.length | 0)) {
      orb.state = OrbStates.AT_PRISM;
      orb.currentPrismKey = orb.edgeToKey;
      orb.progress = 0;
      if (Array.isArray(orb.path) && (orb.pathIndex | 0) >= 0) {
        const nextIdx = (orb.pathIndex | 0) + 1;
        if (orb.path[nextIdx] === orb.edgeToKey) {
          orb.pathIndex = nextIdx;
        }
      }
      ctx.arrivalQueue.push({ orbId: orb.id, prismKey: orb.edgeToKey });
      bumpCounter(ctx, "arrivals_movement");
    }

    moved++;
  }

  if (orbs.length > 0) {
    for (let i = orbs.length - 1; i >= 0; i--) {
      if (orbs[i]?._remove) {
        ctx.state.orbsById?.delete(orbs[i].id);
        orbs.splice(i, 1);
      }
    }
  }
}






